
import React, { useEffect, useRef, useState, useCallback } from "react";
import { useFormikContext } from "formik";
import { motion, AnimatePresence } from "framer-motion";
import { IoIosEyeOff, IoMdEye } from "react-icons/io";
import { FaMinus, FaPlus } from "react-icons/fa";
import { AiOutlineCamera, AiOutlineClose } from "react-icons/ai";
import { createPortal } from "react-dom";
import Select from "react-select";
import { ColComponent } from "../../components/responsive/Responsive";
import { theme } from "../../../config/themes";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { es } from "date-fns/locale";
import { NumericFormat } from "react-number-format";

// import { theme } from "../../../styles/theme";
// ------------------------------------------------------------------
// TIPOS COMPARTIDOS
// ------------------------------------------------------------------
export type HandleModifiedFn = (
  values: Record<string, any>,
  setFieldValue: (name: string, value: any) => void,
) => void | Promise<void>;

export type CaseTransform = "uppercase" | "lowercase" | "none";

export type FormikCtx = ReturnType<
  typeof useFormikContext<Record<string, any>>
>;

type ResponsiveProps = {
  sm?: number;
  md?: number;
  lg?: number;
  xl?: number;
  "2xl"?: number;
};

type TreeNode<T> = T & { children_recursive?: TreeNode<T>[] };

interface Option {
  value: string | number;
  label: string;
}

// ------------------------------------------------------------------
// HELPER: transformación de case
// ------------------------------------------------------------------
function applyCase(
  value: string,
  caseTransform: CaseTransform = "none",
): string {
  if (caseTransform === "uppercase") return value.toUpperCase();
  if (caseTransform === "lowercase") return value.toLowerCase();
  return value;
}

// ------------------------------------------------------------------
// COMPONENTES INTERNOS REUTILIZABLES
// ------------------------------------------------------------------
const FieldError = ({ error }: { error: string | null }) =>
  error ? (
    <motion.div
      initial={{ opacity: 0, y: -4, height: 0 }}
      animate={{ opacity: 1, y: 0, height: "auto" }}
      exit={{ opacity: 0, y: -4, height: 0 }}
      transition={{ duration: 0.15 }}
      style={{
        display: "flex",
        alignItems: "center",
        gap: "6px",
        marginTop: "6px",
        padding: "6px 10px",
        background: theme.colors.feedback.errorLight,
        border: `1px solid ${theme.colors.feedback.errorBorder}`,
        borderRadius: theme.radius.md,
      }}
    >
      <div
        style={{
          width: 5,
          height: 5,
          borderRadius: "50%",
          background: theme.colors.status.error,
        }}
      />
      <span
        style={{
          fontSize: theme.typography.fontSize.sm,
          fontWeight: 500,
          color: theme.colors.status.error,
        }}
      >
        {error}
      </span>
    </motion.div>
  ) : null;

const DisabledField = ({
  label,
  value,
  error,
  multiline = false,
  responsive,
  padding,
}: {
  label: string;
  value: any;
  error: string | null;
  multiline?: boolean;
  responsive?: ResponsiveProps;
  padding?: boolean;
}) => (
  <ColComponent responsive={responsive} autoPadding={padding}>
    <div style={{ position: "relative", marginBottom: "20px" }}>
      <label
        style={{
          position: "absolute",
          left: "12px",
          top: "-9px",
          fontSize: "11px",
          fontWeight: 600,
          color: theme.colors.text.disabled,
          background: theme.colors.background.surface,
          padding: "0 4px",
          letterSpacing: "0.04em",
          textTransform: "uppercase",
          zIndex: 2,
        }}
      >
        {label}
      </label>
      <div
        style={{
          border: `1.5px solid ${theme.colors.border.DEFAULT}`,
          borderRadius: theme.radius.md,
          background: theme.colors.background.surface,
          padding: multiline ? "16px 12px 10px" : "13px 12px",
          minHeight: multiline ? "80px" : "50px",
        }}
      >
        <span
          style={{
            fontSize: theme.typography.fontSize.base,
            color: theme.colors.text.secondary,
            whiteSpace: multiline ? "pre-wrap" : "normal",
          }}
        >
          {value ?? "—"}
        </span>
      </div>
      <FieldError error={error} />
    </div>
  </ColComponent>
);

// ------------------------------------------------------------------
// FORMIK INPUT
// ------------------------------------------------------------------
interface FormikInputProps {
  name: string;
  label: string;
  type?:
    | "text"
    | "email"
    | "password"
    | "number"
    | "tel"
    | "url"
    | "date"
    | "datetime-local"
    | "time";
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  placeholder?: string;
  autoComplete?: string;
  debounceMs?: number;
  mask?: (value: string) => string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  onRightIconClick?: () => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
  caseTransform?: CaseTransform;
  onInput?: (value: string, formik: FormikCtx) => void;
  onChange?: (value: string, formik: FormikCtx) => void;
  handleModified?: HandleModifiedFn;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikInput(props: FormikInputProps) {
  const {
    name,
    label,
    type = "text",
    disabled = false,
    readOnly = false,
    required = false,
    placeholder = " ",
    autoComplete = "off",
    debounceMs,
    mask,
    leftIcon,
    rightIcon,
    onRightIconClick,
    onBlur,
    caseTransform = "none",
    onInput,
    onChange,
    handleModified,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isFocused, setIsFocused] = useState(false);
  const [localValue, setLocalValue] = useState<string>("");
  const debounceTimer = useRef<number>(null);

  useEffect(() => {
    const value = formik.values?.[name];
    setLocalValue(value ?? "");
  }, [formik.values, name]);

  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;
  const hasValue = localValue.length > 0;
  const isActive =
    hasValue || isFocused || type === "date" || type === "datetime-local";

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    let processed = mask ? mask(raw) : raw;
    processed = applyCase(processed, caseTransform);

    setLocalValue(processed);
    onInput?.(processed, formik);

    const updateField = () => {
      formik.setFieldValue(name, processed);
      onChange?.(processed, formik);
      if (handleModified) {
        handleModified(
          { ...formik.values, [name]: processed },
          formik.setFieldValue,
        );
      }
    };

    if (debounceMs) {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      debounceTimer.current = window.setTimeout(updateField, debounceMs);
    } else {
      updateField();
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsFocused(false);
    formik.setFieldTouched(name, true);
    onBlur?.(e);
    if (handleModified && !debounceMs) {
      handleModified(formik.values, formik.setFieldValue);
    }
  };

  if (disabled) {
    return (
      <DisabledField
        label={label}
        value={localValue}
        error={error}
        responsive={responsive}
        padding={padding}
      />
    );
  }

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "20px" }}>
        <label
          htmlFor={name}
          style={{
            position: "absolute",
            left: "12px",
            top: isActive ? "-9px" : "14px",
            fontSize: isActive ? "11px" : theme.typography.fontSize.base,
            fontWeight: isActive ? 600 : 400,
            color: isActive
              ? error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary
              : theme.colors.text.placeholder,
            background: theme.colors.background.card,
            padding: "0 4px",
            pointerEvents: "none",
            transition: theme.transitions.DEFAULT,
            letterSpacing: isActive ? "0.04em" : "0",
            textTransform: isActive ? "uppercase" : "none",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.border.focus
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            boxShadow: isFocused
              ? error
                ? theme.colors.feedback.errorGlow
                : theme.colors.feedback.primaryGlow
              : "none",
            transition: theme.transitions.DEFAULT,
          }}
        >
          {leftIcon && <span style={{ marginLeft: 12 }}>{leftIcon}</span>}
          <input
            id={name}
            name={name}
            type={type}
            value={localValue}
            onChange={handleChange}
            onFocus={() => setIsFocused(true)}
            onBlur={handleBlur}
            readOnly={readOnly}
            required={required}
            placeholder={placeholder}
            autoComplete={autoComplete}
            style={{
              flex: 1,
              padding: `20px ${rightIcon ? "8px" : "12px"} 8px ${
                leftIcon ? "8px" : "12px"
              }`,
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: theme.typography.fontSize.base,
              color: theme.colors.text.primary,
              fontFamily: "inherit",
            }}
          />
          {rightIcon && (
            <button
              type="button"
              onClick={onRightIconClick}
              style={{
                marginRight: 12,
                background: "none",
                border: "none",
                cursor: "pointer",
                color: theme.colors.text.placeholder,
              }}
            >
              {rightIcon}
            </button>
          )}
        </div>
        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK TEXTAREA
// ------------------------------------------------------------------
interface FormikTextAreaProps {
  name: string;
  label: string;
  rows?: number;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  placeholder?: string;
  debounceMs?: number;
  caseTransform?: CaseTransform;
  onInput?: (value: string, formik: FormikCtx) => void;
  onChange?: (value: string, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikTextArea(props: FormikTextAreaProps) {
  const {
    name,
    label,
    rows = 4,
    disabled = false,
    readOnly = false,
    required = false,
    placeholder = " ",
    debounceMs,
    caseTransform = "none",
    onInput,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isFocused, setIsFocused] = useState(false);
  const [localValue, setLocalValue] = useState("");
  const debounceTimer = useRef<number>(null);

  useEffect(() => {
    const value = formik.values?.[name];
    setLocalValue(value ?? "");
  }, [formik.values, name]);

  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;
  const hasValue = localValue.length > 0;
  const isActive = hasValue || isFocused;

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const processed = applyCase(e.target.value, caseTransform);
    setLocalValue(processed);
    onInput?.(processed, formik);

    if (debounceMs) {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      debounceTimer.current = window.setTimeout(() => {
        formik.setFieldValue(name, processed);
        onChange?.(processed, formik);
      }, debounceMs);
    } else {
      formik.setFieldValue(name, processed);
      onChange?.(processed, formik);
    }
  };

  const handleBlur = () => {
    setIsFocused(false);
    formik.setFieldTouched(name, true);
  };

  if (disabled) {
    return (
      <DisabledField
        label={label}
        value={localValue}
        error={error}
        multiline
        responsive={responsive}
        padding={padding}
      />
    );
  }

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "28px" }}>
        <div
          style={{
            borderRadius: "14px",
            padding: "1.5px",
            background: error
              ? `linear-gradient(135deg, ${theme.colors.status.error}, #ff8a80)`
              : isFocused
                ? `linear-gradient(135deg, ${theme.colors.primary.DEFAULT}, #7c3aed, #06b6d4)`
                : `linear-gradient(135deg, ${theme.colors.border.DEFAULT}, ${theme.colors.border.DEFAULT})`,
            transition: theme.transitions.DEFAULT,
            boxShadow: isFocused
              ? error
                ? "0 4px 20px rgba(220,38,38,0.18)"
                : "0 4px 24px rgba(99,102,241,0.18)"
              : "0 2px 8px rgba(0,0,0,0.06)",
          }}
        >
          <div
            style={{
              borderRadius: "13px",
              background: theme.colors.background.card,
              overflow: "hidden",
            }}
          >
            <label
              htmlFor={name}
              style={{
                position: "absolute",
                left: "14px",
                top: isActive ? "8px" : "50%",
                transform: isActive ? "translateY(0)" : "translateY(-50%)",
                fontSize: isActive ? "10px" : theme.typography.fontSize.base,
                fontWeight: isActive ? 700 : 400,
                color: error
                  ? theme.colors.status.error
                  : isFocused
                    ? theme.colors.primary.DEFAULT
                    : isActive
                      ? theme.colors.text.secondary
                      : theme.colors.text.placeholder,
                letterSpacing: isActive ? "0.07em" : "0",
                textTransform: isActive ? "uppercase" : "none",
                pointerEvents: "none",
                transition: "all 0.22s cubic-bezier(0.4,0,0.2,1)",
                zIndex: 2,
              }}
            >
              {label}
              {required && (
                <span
                  style={{ color: theme.colors.status.error, marginLeft: 2 }}
                >
                  *
                </span>
              )}
            </label>
            <textarea
              id={name}
              value={localValue}
              onChange={handleChange}
              onFocus={() => setIsFocused(true)}
              onBlur={handleBlur}
              rows={rows}
              readOnly={readOnly}
              placeholder={placeholder}
              style={{
                width: "100%",
                padding: "28px 14px 12px",
                background: "transparent",
                border: "none",
                outline: "none",
                resize: "none",
                fontSize: theme.typography.fontSize.base,
                lineHeight: "1.6",
                color: theme.colors.text.primary,
                fontFamily: "inherit",
                caretColor: error
                  ? theme.colors.status.error
                  : theme.colors.primary.DEFAULT,
              }}
            />
          </div>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "6px",
          }}
        >
          <FieldError error={error} />
          {hasValue && (
            <span
              style={{
                fontSize: theme.typography.fontSize.xs,
                color: isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.disabled,
              }}
            >
              {localValue.length} caracteres
            </span>
          )}
        </div>
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK PASSWORD
// ------------------------------------------------------------------
interface FormikPasswordProps {
  name: string;
  label: string;
  disabled?: boolean;
  required?: boolean;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikPassword(props: FormikPasswordProps) {
  const {
    name,
    label,
    disabled = false,
    required = false,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;
  const formik = useFormikContext<Record<string, any>>();
  const [showPassword, setShowPassword] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const value = (formik.values?.[name] as string) ?? "";
  const hasValue = value.length > 0;
  const isActive = hasValue || isFocused;
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  if (disabled) {
    return (
      <DisabledField
        label={label}
        value={value}
        error={error}
        responsive={responsive}
        padding={padding}
      />
    );
  }

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "20px" }}>
        <label
          htmlFor={name}
          style={{
            position: "absolute",
            left: "12px",
            top: isActive ? "-9px" : "14px",
            fontSize: isActive ? "11px" : theme.typography.fontSize.base,
            fontWeight: isActive ? 600 : 400,
            color: isActive
              ? error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary
              : theme.colors.text.placeholder,
            background: theme.colors.background.card,
            padding: "0 4px",
            transition: theme.transitions.DEFAULT,
            letterSpacing: isActive ? "0.04em" : "0",
            textTransform: isActive ? "uppercase" : "none",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.border.focus
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            boxShadow: isFocused ? theme.colors.feedback.primaryGlow : "none",
            transition: theme.transitions.DEFAULT,
          }}
        >
          <input
            type={showPassword ? "text" : "password"}
            id={name}
            value={value}
            onChange={(e) => formik.setFieldValue(name, e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => {
              setIsFocused(false);
              formik.setFieldTouched(name, true);
            }}
            style={{
              flex: 1,
              padding: "20px 12px 8px",
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: theme.typography.fontSize.base,
              color: theme.colors.text.primary,
            }}
          />
          <button
            type="button"
            onClick={() => setShowPassword((p) => !p)}
            style={{
              padding: "0 12px",
              background: "none",
              border: "none",
              cursor: "pointer",
              color: theme.colors.text.placeholder,
            }}
          >
            {showPassword ? <IoMdEye size={18} /> : <IoIosEyeOff size={18} />}
          </button>
        </div>
        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK NUMBER
// ------------------------------------------------------------------
interface FormikNumberProps {
  name: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
  decimals?: boolean;
  romanNumerals?: boolean;
  disabled?: boolean;
  required?: boolean;
  onChange?: (value: number, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikNumber(props: FormikNumberProps) {
  const {
    name,
    label,
    min = 0,
    max = Infinity,
    step = 1,
    decimals = false,
    romanNumerals = false,
    disabled = false,
    required = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isFocused, setIsFocused] = useState(false);
  const [inputValue, setInputValue] = useState<string>("");

  const value = (formik.values?.[name] as number) ?? 0;

  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  // Conversión a números romanos
  const toRoman = (num: number): string => {
    const map: [string, number][] = [
      ["M", 1000],
      ["CM", 900],
      ["D", 500],
      ["CD", 400],
      ["C", 100],
      ["XC", 90],
      ["L", 50],
      ["XL", 40],
      ["X", 10],
      ["IX", 9],
      ["V", 5],
      ["IV", 4],
      ["I", 1],
    ];
    let roman = "";
    let n = num;
    for (const [letter, val] of map) {
      while (n >= val) {
        roman += letter;
        n -= val;
      }
    }
    return roman;
  };

  // Formateo para mostrar
  const formatDisplay = (num: number) => {
    if (romanNumerals) return toRoman(num);
    return decimals ? num.toFixed(2) : Math.floor(num).toString();
  };

  // Actualiza el valor real (Formik + clamp)
  const setValue = (newVal: number) => {
    const clamped = Math.min(max, Math.max(min, newVal));
    formik.setFieldValue(name, clamped);
    onChange?.(clamped, formik);
    // Sincronizar el inputValue con el nuevo valor formateado
    if (!romanNumerals) {
      setInputValue(formatDisplay(clamped));
    }
  };

  // Manejo del cambio de texto en el input (solo si no es romano)
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (romanNumerals) return;
    const raw = e.target.value;
    setInputValue(raw);
  };

  // Al perder foco, parsear el texto a número
  const handleBlur = () => {
    setIsFocused(false);
    formik.setFieldTouched(name, true);

    if (romanNumerals) {
      // En modo romano no se edita, solo se marca touched
      return;
    }

    let parsed = parseFloat(inputValue);
    if (isNaN(parsed)) {
      parsed = min;
    }
    // Si decimals es false, redondeamos a entero
    if (!decimals) {
      parsed = Math.floor(parsed);
    }
    setValue(parsed);
  };

  // Cuando el valor externo (value) cambia, actualizar inputValue si no está enfocado
  // para mantener sincronía
  React.useEffect(() => {
    if (!isFocused && !romanNumerals) {
      setInputValue(formatDisplay(value));
    }
  }, [value, isFocused, romanNumerals, decimals]);

  // Inicializar inputValue
  React.useEffect(() => {
    if (!romanNumerals) {
      setInputValue(formatDisplay(value));
    }
  }, []);

  if (disabled) {
    return (
      <DisabledField
        label={label}
        value={formatDisplay(value)}
        error={error}
        responsive={responsive}
        padding={padding}
      />
    );
  }

  // Mostramos el valor formateado (romano) o el texto editable
  const displayValue = romanNumerals ? formatDisplay(value) : inputValue;

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "20px" }}>
        <label
          style={{
            position: "absolute",
            left: "12px",
            top: "-9px",
            fontSize: "11px",
            fontWeight: 600,
            color: error
              ? theme.colors.status.error
              : isFocused
                ? theme.colors.primary.DEFAULT
                : theme.colors.text.secondary,
            background: theme.colors.background.card,
            padding: "0 4px",
            letterSpacing: "0.04em",
            textTransform: "uppercase",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error ? theme.colors.border.error : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            overflow: "hidden",
          }}
        >
          <button
            type="button"
            onClick={() => setValue(value - step)}
            style={{
              width: 40,
              height: 44,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: theme.colors.background.surface,
              border: "none",
              borderRight: `1px solid ${theme.colors.border.DEFAULT}`,
              cursor: "pointer",
            }}
          >
            <FaMinus size={10} />
          </button>
          <input
            type="text"
            value={displayValue}
            onFocus={() => setIsFocused(true)}
            onBlur={handleBlur}
            onChange={handleTextChange}
            readOnly={romanNumerals} // Si es romano, no editable
            style={{
              flex: 1,
              padding: "10px 8px",
              textAlign: "center",
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: theme.typography.fontSize.base,
              fontWeight: 600,
              color: theme.colors.text.primary,
            }}
          />
          <button
            type="button"
            onClick={() => setValue(value + step)}
            style={{
              width: 40,
              height: 44,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: theme.colors.background.surface,
              border: "none",
              borderLeft: `1px solid ${theme.colors.border.DEFAULT}`,
              cursor: "pointer",
            }}
          >
            <FaPlus size={10} />
          </button>
        </div>
        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK CHECKBOX
// ------------------------------------------------------------------
interface FormikCheckboxProps {
  name: string;
  label: string;
  disabled?: boolean;
  required?: boolean;
  onChange?: (value: boolean, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikCheckbox(props: FormikCheckboxProps) {
  const {
    name,
    label,
    disabled = false,
    required = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;
  const formik = useFormikContext<Record<string, any>>();
  const value = !!formik.values?.[name];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  const handleToggle = () => {
    if (disabled) return;
    const next = !value;
    formik.setFieldValue(name, next);
    onChange?.(next, formik);
  };

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          marginBottom: "20px",
          opacity: disabled ? 0.5 : 1,
          cursor: disabled ? "not-allowed" : "pointer",
        }}
        onClick={handleToggle}
      >
        <div
          style={{
            width: 20,
            height: 20,
            borderRadius: theme.radius.sm,
            background: value
              ? theme.colors.primary.DEFAULT
              : theme.colors.background.card,
            border: `2px solid ${
              error
                ? theme.colors.border.error
                : value
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.border.DEFAULT
            }`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {value && (
            <svg
              width={12}
              height={12}
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth={3}
            >
              <polyline points="20 6 9 17 4 12" />
            </svg>
          )}
        </div>
        <label
          style={{
            fontSize: theme.typography.fontSize.base,
            fontWeight: 500,
            color: value
              ? theme.colors.text.primary
              : theme.colors.text.secondary,
            userSelect: "none",
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>
      </div>
      <FieldError error={error} />
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK SWITCH
// ------------------------------------------------------------------
interface FormikSwitchProps {
  name: string;
  label: string;
  disabled?: boolean;
  onChange?: (value: boolean, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
}

export function FormikSwitch(props: FormikSwitchProps) {
  const {
    name,
    label,
    disabled = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
  } = props;
  const formik = useFormikContext<Record<string, any>>();
  const value = !!formik.values?.[name];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  return (
    <ColComponent responsive={responsive}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          marginBottom: "20px",
          opacity: disabled ? 0.5 : 1,
        }}
      >
        <label
          style={{
            position: "relative",
            display: "inline-flex",
            cursor: disabled ? "not-allowed" : "pointer",
          }}
        >
          <input
            type="checkbox"
            checked={value}
            disabled={disabled}
            onChange={(e) => {
              const next = e.target.checked;
              formik.setFieldValue(name, next ? 1 : 0);
              onChange?.(next, formik);
            }}
            style={{ position: "absolute", opacity: 0, width: 0, height: 0 }}
          />
          <div
            style={{
              width: 52,
              height: 28,
              borderRadius: 100,
              background: value
                ? theme.colors.primary.DEFAULT
                : theme.colors.border.DEFAULT,
              transition: theme.transitions.DEFAULT,
              position: "relative",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 3,
                left: value ? 28 : 3,
                width: 22,
                height: 22,
                borderRadius: "50%",
                background: theme.colors.background.card,
                transition: theme.transitions.DEFAULT,
              }}
            />
          </div>
        </label>

        <span
          style={{
            fontSize: theme.typography.fontSize.base,
            fontWeight: 500,
            color: theme.colors.text.primary,
          }}
        >
          {label}
        </span>

        <span
          style={{
            fontSize: theme.typography.fontSize.sm,
            fontWeight: 500,
            color: value
              ? theme.colors.primary.DEFAULT
              : theme.colors.text.disabled,
            transition: theme.transitions.DEFAULT,
          }}
        >
          ({value ? "Si" : "No"})
        </span>

        {error && (
          <span
            style={{
              fontSize: theme.typography.fontSize.sm,
              color: theme.colors.status.error,
            }}
          >
            {error}
          </span>
        )}
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK RADIO
// ------------------------------------------------------------------
interface FormikRadioProps<TOption> {
  name: string;
  label: string;
  options: TOption[];
  idKey: keyof TOption;
  labelKey: keyof TOption;
  disabled?: boolean;
  required?: boolean;
  onChange?: (value: any, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikRadio<TOption>(props: FormikRadioProps<TOption>) {
  const {
    name,
    label,
    options,
    idKey,
    labelKey,
    disabled = false,
    required = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;
  const formik = useFormikContext<Record<string, any>>();
  const value = formik.values?.[name];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div
        style={{
          position: "relative",
          marginBottom: "20px",
          opacity: disabled ? 0.5 : 1,
        }}
      >
        <label
          style={{
            position: "absolute",
            left: "12px",
            top: "-9px",
            fontSize: "11px",
            fontWeight: 600,
            color: error
              ? theme.colors.status.error
              : theme.colors.text.secondary,
            background: theme.colors.background.card,
            padding: "0 4px",
            letterSpacing: "0.04em",
            textTransform: "uppercase",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>
        <div
          style={{
            border: `1.5px solid ${
              error ? theme.colors.border.error : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            padding: "16px 12px 10px",
            background: theme.colors.background.card,
          }}
        >
          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
            {options.map((option) => {
              const optValue = option[idKey];
              const isSelected = String(value) === String(optValue);
              return (
                <label
                  key={String(optValue)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    padding: "8px 14px",
                    borderRadius: theme.radius.md,
                    border: `1.5px solid ${
                      isSelected
                        ? error
                          ? theme.colors.border.error
                          : theme.colors.primary.DEFAULT
                        : theme.colors.border.DEFAULT
                    }`,
                    background: isSelected
                      ? error
                        ? "rgba(220,38,38,0.06)"
                        : theme.colors.feedback.primaryLight
                      : theme.colors.background.card,
                    cursor: disabled ? "not-allowed" : "pointer",
                    transition: theme.transitions.DEFAULT,
                  }}
                  onClick={() => {
                    if (!disabled) {
                      formik.setFieldValue(name, optValue);
                      onChange?.(optValue, formik);
                    }
                  }}
                >
                  <div
                    style={{
                      width: 16,
                      height: 16,
                      borderRadius: "50%",
                      border: `2px solid ${
                        isSelected
                          ? error
                            ? theme.colors.border.error
                            : theme.colors.primary.DEFAULT
                          : theme.colors.border.DEFAULT
                      }`,
                      background: isSelected
                        ? error
                          ? theme.colors.border.error
                          : theme.colors.primary.DEFAULT
                        : theme.colors.background.card,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {isSelected && (
                      <div
                        style={{
                          width: 5,
                          height: 5,
                          borderRadius: "50%",
                          background: "white",
                        }}
                      />
                    )}
                  </div>
                  <span
                    style={{
                      fontSize: "13.5px",
                      fontWeight: isSelected ? 600 : 400,
                      color: isSelected
                        ? theme.colors.text.primary
                        : theme.colors.text.secondary,
                    }}
                  >
                    {String(option[labelKey])}
                  </span>
                </label>
              );
            })}
          </div>
        </div>
        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK AUTOCOMPLETE
// ------------------------------------------------------------------
interface FormikAutocompleteProps<TOption> {
  name: string;
  label: string;
  options: TreeNode<TOption>[];
  idKey: keyof TOption;
  labelKey: keyof TOption;
  loading?: boolean;
  disabled?: boolean;
  required?: boolean;
  responsive?: ResponsiveProps;
  padding?: boolean;
  onSelect?: (value: TOption) => void;
  onRefresh?: () => void | Promise<void>;
  onAdd?: () => void;
  onChange?: (value: any, formik: FormikCtx) => void;
  onInput?: (text: string, formik: FormikCtx) => void;
  caseTransform?: CaseTransform;
}

export function FormikAutocomplete<TOption>(
  props: FormikAutocompleteProps<TOption>,
) {
  const {
    name,
    label,
    options,
    idKey,
    labelKey,
    loading = false,
    disabled = false,
    required = false,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
    onSelect,
    onRefresh,
    onAdd,
    onChange,
    onInput,
    caseTransform = "none",
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [filteredOptions, setFilteredOptions] = useState(options);
  const [textSearch, setTextSearch] = useState("");
  const [showOptions, setShowOptions] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLUListElement>(null);

  const value = formik.values?.[name];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;
  const hasValue = textSearch.length > 0;
  const isActive = hasValue || isFocused;

  const flattenOptions = (
    opts: TreeNode<TOption>[],
    depth = 0,
  ): Array<{ item: TreeNode<TOption>; depth: number; isGroup: boolean }> => {
    const result: Array<{
      item: TreeNode<TOption>;
      depth: number;
      isGroup: boolean;
    }> = [];
    for (const item of opts) {
      const hasChildren =
        Array.isArray(item.children_recursive) &&
        item.children_recursive.length > 0;
      result.push({ item, depth, isGroup: hasChildren });
      if (hasChildren)
        result.push(...flattenOptions(item.children_recursive!, depth + 1));
    }
    return result;
  };

  const flatList = flattenOptions(filteredOptions);

  const filterTree = (
    opts: TreeNode<TOption>[],
    query: string,
  ): TreeNode<TOption>[] => {
    const lower = query.toLowerCase();
    return opts.reduce<TreeNode<TOption>[]>((acc, item) => {
      const labelMatch = String(item[labelKey]).toLowerCase().includes(lower);
      const filteredChildren = item.children_recursive
        ? filterTree(item.children_recursive, query)
        : [];
      if (labelMatch || filteredChildren.length)
        acc.push({ ...item, children_recursive: filteredChildren });
      return acc;
    }, []);
  };

  const updateTextFromValue = useCallback(() => {
    const findInTree = (
      opts: TreeNode<TOption>[],
    ): TreeNode<TOption> | null => {
      for (const opt of opts) {
        const optValue = String(opt[idKey]);
        const currentValue =
          value !== null && value !== undefined ? String(value) : "";
        if (optValue === currentValue) return opt;
        if (opt.children_recursive) {
          const found = findInTree(opt.children_recursive);
          if (found) return found;
        }
      }
      return null;
    };
    const selected = findInTree(options);
    setTextSearch(selected ? String(selected[labelKey]) : "");
  }, [value, options, idKey, labelKey]);

  useEffect(() => {
    updateTextFromValue();
  }, [updateTextFromValue]);
  useEffect(() => {
    setFilteredOptions(options);
  }, [options]);

  const handleFilter = (rawQuery: string) => {
    const query = applyCase(rawQuery, caseTransform);
    setTextSearch(query);
    onInput?.(query, formik);
    if (!query) {
      setFilteredOptions(options);
      if (value) formik.setFieldValue(name, null);
    } else {
      setFilteredOptions(filterTree(options, query));
    }
    setActiveIndex(-1);
  };

  const selectOption = (item: TreeNode<TOption>) => {
    setTextSearch(String(item[labelKey]));
    formik.setFieldValue(name, item[idKey]);
    formik.setFieldTouched(name, true);
    setShowOptions(false);
    setIsFocused(false);
    onSelect?.(item);
    onChange?.(item[idKey], formik);
  };

  const handleRefresh = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!onRefresh || isRefreshing) return;
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAdd?.();
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        inputRef.current &&
        !inputRef.current.contains(e.target as Node) &&
        menuRef.current &&
        !menuRef.current.contains(e.target as Node)
      ) {
        setShowOptions(false);
        setIsFocused(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showOptions || flatList.length === 0) return;
    if (e.key === "ArrowDown")
      setActiveIndex((prev) => (prev + 1) % flatList.length);
    else if (e.key === "ArrowUp")
      setActiveIndex((prev) => (prev - 1 + flatList.length) % flatList.length);
    else if (e.key === "Enter" && activeIndex >= 0)
      selectOption(flatList[activeIndex].item);
    else if (e.key === "Escape") {
      setShowOptions(false);
      setIsFocused(false);
    }
  };

  const actionButtonStyle: React.CSSProperties = {
    padding: "0 7px",
    background: "none",
    border: "none",
    cursor: "pointer",
    color: theme.colors.text.disabled,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: theme.radius.md,
    height: "28px",
    width: "28px",
    transition: "color 0.15s, background 0.15s",
  };

  if (disabled)
    return (
      <DisabledField
        label={label}
        value={textSearch}
        error={error}
        responsive={responsive}
        padding={padding}
      />
    );

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "20px" }}>
        <label
          htmlFor={name}
          style={{
            position: "absolute",
            left: "12px",
            top: isActive ? "-9px" : "14px",
            fontSize: isActive ? "11px" : theme.typography.fontSize.base,
            fontWeight: isActive ? 600 : 400,
            color: isActive
              ? error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary
              : theme.colors.text.placeholder,
            background: theme.colors.background.card,
            padding: "0 4px",
            transition: theme.transitions.DEFAULT,
            letterSpacing: isActive ? "0.04em" : "0",
            textTransform: isActive ? "uppercase" : "none",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.border.focus
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            boxShadow: isFocused ? theme.colors.feedback.primaryGlow : "none",
            transition: theme.transitions.DEFAULT,
          }}
        >
          <input
            ref={inputRef}
            id={name}
            type="text"
            value={textSearch}
            placeholder=" "
            autoComplete="off"
            onFocus={() => {
              setIsFocused(true);
              setShowOptions(true);
              setFilteredOptions(options);
            }}
            onChange={(e) => handleFilter(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => {
              setIsFocused(false);
              formik.setFieldTouched(name, true);
            }}
            style={{
              flex: 1,
              padding: "20px 12px 8px",
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: theme.typography.fontSize.base,
              color: theme.colors.text.primary,
            }}
          />

          {(onRefresh || onAdd) && (
            <div
              style={{
                width: "1px",
                height: "20px",
                background: theme.colors.border.DEFAULT,
                margin: "0 2px",
                flexShrink: 0,
              }}
            />
          )}

          {onRefresh && (
            <button
              type="button"
              title="Actualizar opciones"
              onClick={handleRefresh}
              disabled={isRefreshing}
              style={{
                ...actionButtonStyle,
                cursor: isRefreshing ? "not-allowed" : "pointer",
                opacity: isRefreshing ? 0.6 : 1,
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color =
                  theme.colors.primary.DEFAULT;
                (e.currentTarget as HTMLButtonElement).style.background =
                  theme.colors.feedback.primaryLight;
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color =
                  theme.colors.text.disabled;
                (e.currentTarget as HTMLButtonElement).style.background =
                  "none";
              }}
            >
              {isRefreshing ? (
                <div
                  style={{
                    width: 13,
                    height: 13,
                    border: `2px solid ${theme.colors.border.DEFAULT}`,
                    borderTopColor: theme.colors.primary.DEFAULT,
                    borderRadius: "50%",
                    animation: "spin 0.7s linear infinite",
                  }}
                />
              ) : (
                <svg
                  width={14}
                  height={14}
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M1 4v6h6" />
                  <path d="M23 20v-6h-6" />
                  <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15" />
                </svg>
              )}
            </button>
          )}

          {onAdd && (
            <button
              type="button"
              title="Agregar nuevo"
              onClick={handleAdd}
              style={actionButtonStyle}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color =
                  theme.colors.status.success;
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color =
                  theme.colors.text.disabled;
                (e.currentTarget as HTMLButtonElement).style.background =
                  "none";
              }}
            >
              <svg
                width={15}
                height={15}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2.5}
                strokeLinecap="round"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          )}

          {(onRefresh || onAdd) && (
            <div
              style={{
                width: "1px",
                height: "20px",
                background: theme.colors.border.DEFAULT,
                margin: "0 2px",
                flexShrink: 0,
              }}
            />
          )}

          {loading ? (
            <div style={{ padding: "0 12px" }}>
              <div
                style={{
                  width: 16,
                  height: 16,
                  border: `2px solid ${theme.colors.border.DEFAULT}`,
                  borderTopColor: theme.colors.primary.DEFAULT,
                  borderRadius: "50%",
                  animation: "spin 0.7s linear infinite",
                }}
              />
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowOptions((s) => !s)}
              style={{
                padding: "0 12px",
                background: "none",
                border: "none",
                cursor: "pointer",
                color: theme.colors.text.placeholder,
              }}
            >
              <svg
                width={16}
                height={16}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                style={{
                  transform: showOptions ? "rotate(180deg)" : "none",
                  transition: "transform 0.18s",
                }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>
          )}
        </div>

        <AnimatePresence>
          {showOptions && (
            <motion.ul
              ref={menuRef}
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.13 }}
              style={{
                position: "absolute",
                zIndex: theme.zIndex.dropdown,
                top: "calc(100% + 6px)",
                left: 0,
                right: 0,
                background: theme.colors.background.card,
                border: `1.5px solid ${theme.colors.border.DEFAULT}`,
                borderRadius: theme.radius.md,
                boxShadow: theme.shadows.dropdown,
                maxHeight: 280,
                overflowY: "auto",
                listStyle: "none",
                margin: 0,
                padding: "4px",
              }}
            >
              {flatList.length ? (
                flatList.map(({ item, depth, isGroup }, idx) => (
                  <li
                    key={`${depth}-${String(item[idKey])}`}
                    onClick={() => selectOption(item)}
                    style={{
                      padding: `8px 10px 8px ${12 + depth * 18}px`,
                      borderRadius: theme.radius.md,
                      background:
                        activeIndex === idx
                          ? theme.colors.feedback.primaryLight
                          : "transparent",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                    onMouseEnter={() => setActiveIndex(idx)}
                  >
                    {depth > 0 && (
                      <svg
                        width={10}
                        height={10}
                        viewBox="0 0 12 12"
                        fill="none"
                      >
                        <path
                          d="M2 0 L2 6 L12 6"
                          stroke="currentColor"
                          strokeWidth="1.5"
                        />
                      </svg>
                    )}
                    {isGroup ? (
                      <svg
                        width={13}
                        height={13}
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke={theme.colors.primary.DEFAULT}
                      >
                        <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z" />
                      </svg>
                    ) : (
                      <div
                        style={{
                          width: 6,
                          height: 6,
                          borderRadius: "50%",
                          background: theme.colors.border.DEFAULT,
                        }}
                      />
                    )}
                    <span
                      style={{
                        fontSize: "13.5px",
                        fontWeight: isGroup ? 600 : 400,
                      }}
                    >
                      {String(item[labelKey])}
                    </span>
                  </li>
                ))
              ) : (
                <li
                  style={{
                    padding: "16px",
                    textAlign: "center",
                    color: theme.colors.text.disabled,
                  }}
                >
                  No hay opciones
                </li>
              )}
            </motion.ul>
          )}
        </AnimatePresence>

        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK COLOR PICKER
// ------------------------------------------------------------------
interface FormikColorPickerProps {
  name: string;
  label: string;
  disabled?: boolean;
  required?: boolean;
  onChange?: (value: string, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikColorPicker(props: FormikColorPickerProps) {
  const {
    name,
    label,
    disabled = false,
    required = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;
  const formik = useFormikContext<Record<string, any>>();
  const [isOpen, setIsOpen] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);
  const colorPalette = [
    // Blue
    "#DBEAFE", // blue-100
    "#BFDBFE", // blue-200
    "#93C5FD", // blue-300
    "#60A5FA", // blue-400
    "#3B82F6", // blue-500
    "#2563EB", // blue-600
    "#1D4ED8", // blue-700
    "#1E40AF", // blue-800
    "#1E3A8A", // blue-900

    // Red
    "#FEE2E2", // red-100
    "#FECACA", // red-200
    "#FCA5A5", // red-300
    "#F87171", // red-400
    "#EF4444", // red-500
    "#DC2626", // red-600
    "#B91C1C", // red-700
    "#991B1B", // red-800
    "#7F1D1D", // red-900

    // Emerald (Green)
    "#D1FAE5", // emerald-100
    "#A7F3D0", // emerald-200
    "#6EE7B7", // emerald-300
    "#34D399", // emerald-400
    "#10B981", // emerald-500
    "#059669", // emerald-600
    "#047857", // emerald-700
    "#065F46", // emerald-800
    "#064E3B", // emerald-900

    // Amber
    "#FEF3C7", // amber-100
    "#FDE68A", // amber-200
    "#FCD34D", // amber-300
    "#FBBF24", // amber-400
    "#F59E0B", // amber-500
    "#D97706", // amber-600
    "#B45309", // amber-700
    "#92400E", // amber-800
    "#78350F", // amber-900

    // Violet
    "#EDE9FE", // violet-100
    "#DDD6FE", // violet-200
    "#C4B5FD", // violet-300
    "#A78BFA", // violet-400
    "#8B5CF6", // violet-500
    "#7C3AED", // violet-600
    "#6D28D9", // violet-700
    "#5B21B6", // violet-800
    "#4C1D95", // violet-900

    // Pink
    "#FCE7F3", // pink-100
    "#FBCFE8", // pink-200
    "#F9A8D4", // pink-300
    "#F472B6", // pink-400
    "#EC4899", // pink-500
    "#DB2777", // pink-600
    "#BE185D", // pink-700
    "#9D174D", // pink-800
    "#831843", // pink-900

    // Cyan
    "#CFFAFE", // cyan-100
    "#A5F3FC", // cyan-200
    "#67E8F9", // cyan-300
    "#22D3EE", // cyan-400
    "#06B6D4", // cyan-500
    "#0891B2", // cyan-600
    "#0E7490", // cyan-700
    "#155E75", // cyan-800
    "#164E63", // cyan-900

    // Orange
    "#FFEDD5", // orange-100
    "#FED7AA", // orange-200
    "#FDBA74", // orange-300
    "#FB923C", // orange-400
    "#F97316", // orange-500
    "#EA580C", // orange-600
    "#C2410C", // orange-700
    "#9A3412", // orange-800
    "#7C2D12", // orange-900

    // Indigo
    "#E0E7FF", // indigo-100
    "#C7D2FE", // indigo-200
    "#A5B4FC", // indigo-300
    "#818CF8", // indigo-400
    "#6366F1", // indigo-500
    "#4F46E5", // indigo-600
    "#4338CA", // indigo-700
    "#3730A3", // indigo-800
    "#312E81", // indigo-900

    // Teal
    "#CCFBF1", // teal-100
    "#99F6E4", // teal-200
    "#5EEAD4", // teal-300
    "#2DD4BF", // teal-400
    "#14B8A6", // teal-500
    "#0D9488", // teal-600
    "#0F766E", // teal-700
    "#115E59", // teal-800
    "#134E4A", // teal-900

    // Fuchsia
    "#FAE8FF", // fuchsia-100
    "#F5D0FE", // fuchsia-200
    "#F0ABFC", // fuchsia-300
    "#E879F9", // fuchsia-400
    "#D946EF", // fuchsia-500
    "#C026D3", // fuchsia-600
    "#A21CAF", // fuchsia-700
    "#86198F", // fuchsia-800
    "#701A75", // fuchsia-900

    // Lime
    "#ECFCCB", // lime-100
    "#D9F99D", // lime-200
    "#BEF264", // lime-300
    "#A3E635", // lime-400
    "#84CC16", // lime-500
    "#65A30D", // lime-600
    "#4D7C0F", // lime-700
    "#3F6212", // lime-800
    "#365314", // lime-900

    // Gray
    "#F3F4F6", // gray-100
    "#E5E7EB", // gray-200
    "#D1D5DB", // gray-300
    "#9CA3AF", // gray-400
    "#6B7280", // gray-500
    "#4B5563", // gray-600
    "#374151", // gray-700
    "#1F2937", // gray-800
    "#111827", // gray-900

    // Slate
    "#F1F5F9", // slate-100
    "#E2E8F0", // slate-200
    "#CBD5E1", // slate-300
    "#94A3B8", // slate-400
    "#64748B", // slate-500
    "#475569", // slate-600
    "#334155", // slate-700
    "#1E293B", // slate-800
    "#0F172A", // slate-900

    // Zinc (extra neutral)
    "#F4F4F5", // zinc-100
    "#E4E4E7", // zinc-200
    "#D4D4D8", // zinc-300
    "#A1A1AA", // zinc-400
    "#71717A", // zinc-500
    "#52525B", // zinc-600
    "#3F3F46", // zinc-700
    "#27272A", // zinc-800
    "#18181B", // zinc-900
  ];
  const currentColor =
    (formik.values?.[name] as string) || colorPalette[0] || "#000000";
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node))
        setIsOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selectColor = (color: string) => {
    formik.setFieldValue(name, color);
    onChange?.(color, formik);
    setIsOpen(false);
  };

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div
        ref={pickerRef}
        style={{ position: "relative", marginBottom: "20px" }}
      >
        <button
          type="button"
          onClick={() => !disabled && setIsOpen((o) => !o)}
          disabled={disabled}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            gap: "14px",
            padding: "10px 14px",
            background: theme.colors.background.card,
            border: `1.5px solid ${
              isOpen
                ? theme.colors.border.focus
                : error
                  ? theme.colors.border.error
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            cursor: disabled ? "not-allowed" : "pointer",
            transition: theme.transitions.DEFAULT,
            boxShadow: isOpen
              ? theme.colors.feedback.primaryGlow
              : theme.shadows.sm,
            opacity: disabled ? 0.5 : 1,
          }}
        >
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: theme.radius.md,
              background: currentColor,
              border: "1px solid rgba(0,0,0,0.08)",
            }}
          />
          <div style={{ flex: 1, textAlign: "left" }}>
            <div
              style={{
                fontSize: "13px",
                fontWeight: 600,
                color: theme.colors.text.primary,
              }}
            >
              {label}
            </div>
            <div
              style={{
                fontSize: theme.typography.fontSize.sm,
                color: theme.colors.text.disabled,
                fontFamily: "monospace",
              }}
            >
              {currentColor.toUpperCase()}
            </div>
          </div>
          <svg
            width={16}
            height={16}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            style={{ transform: isOpen ? "rotate(180deg)" : "none" }}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </button>
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.15 }}
              style={{
                position: "absolute",
                top: "calc(100% + 8px)",
                left: 0,
                right: 0,
                zIndex: theme.zIndex.dropdown,
                background: theme.colors.background.card,
                border: `1.5px solid ${theme.colors.border.DEFAULT}`,
                borderRadius: theme.radius.xl,
                boxShadow: theme.shadows.dropdown,
              }}
            >
              <div
                style={{
                  padding: "12px 14px",
                  borderBottom: `1px solid ${theme.colors.border.DEFAULT}`,
                  background: theme.colors.background.surface,
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 28,
                      height: 28,
                      borderRadius: theme.radius.sm,
                      background: currentColor,
                    }}
                  />
                  <div>
                    <div
                      style={{
                        fontSize: theme.typography.fontSize.sm,
                        fontWeight: 600,
                      }}
                    >
                      Color seleccionado
                    </div>
                    <div
                      style={{
                        fontSize: "11px",
                        fontFamily: "monospace",
                      }}
                    >
                      {currentColor.toUpperCase()}
                    </div>
                  </div>
                </div>
              </div>
              <div
                style={{
                  padding: "14px",
                  maxHeight: "220px",
                  overflowY: "auto",
                }}
              >
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(10, 1fr)",
                    gap: "8px",
                  }}
                >
                  {colorPalette.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => selectColor(color)}
                      style={{
                        paddingBottom: "100%",
                        position: "relative",
                        borderRadius: theme.radius.sm,
                        background: color,
                        border:
                          currentColor === color
                            ? "2px solid white"
                            : "2px solid transparent",
                        outline:
                          currentColor === color
                            ? `2px solid ${theme.colors.primary.DEFAULT}`
                            : "none",
                        transform:
                          currentColor === color ? "scale(1.15)" : "scale(1)",
                        transition: theme.transitions.DEFAULT,
                      }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK IMAGE INPUT
// ------------------------------------------------------------------
interface FormikImageInputProps {
  name: string;
  label: string;
  disabled?: boolean;
  acceptedFileTypes?: string;
  multiple?: boolean;
  maxFiles?: number;
  onChange?: (value: File | File[] | null, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikImageInput(props: FormikImageInputProps) {
  const {
    name,
    label,
    disabled = false,
    acceptedFileTypes = "image/*",
    multiple = false,
    maxFiles = 5,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const { setFieldValue, values, errors, touched } =
    useFormikContext<Record<string, any>>();
  const formik = useFormikContext<Record<string, any>>();
  const [previews, setPreviews] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const currentValue = values[name];
    if (multiple && Array.isArray(currentValue)) {
      setPreviews(
        currentValue.filter((f: any) => typeof f === "string") as string[],
      );
    } else if (!multiple && typeof currentValue === "string") {
      setPreviews([currentValue]);
    } else {
      setPreviews([]);
    }
  }, [values, name, multiple]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;
    const fileList = Array.from(files);
    if (multiple) {
      if (fileList.length + previews.length > maxFiles) return;
      const newPreviews = fileList.map((f) => URL.createObjectURL(f));
      setPreviews((prev) => [...prev, ...newPreviews]);
      const currentFiles = (values[name] as File[]) || [];
      const nextFiles = [...currentFiles, ...fileList];
      setFieldValue(name, nextFiles);
      onChange?.(nextFiles, formik);
    } else {
      setPreviews([URL.createObjectURL(fileList[0])]);
      setFieldValue(name, fileList[0]);
      onChange?.(fileList[0], formik);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleRemove = (index: number) => {
    if (multiple) {
      const currentFiles = (values[name] as File[]) || [];
      const nextFiles = currentFiles.filter((_, i) => i !== index);
      setFieldValue(name, nextFiles);
      onChange?.(nextFiles, formik);
      URL.revokeObjectURL(previews[index]);
      setPreviews(previews.filter((_, i) => i !== index));
    } else {
      if (previews[0]) URL.revokeObjectURL(previews[0]);
      setPreviews([]);
      setFieldValue(name, null);
      onChange?.(null, formik);
    }
  };

  const error = touched[name] && errors[name] ? String(errors[name]) : null;

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ marginBottom: "20px" }}>
        <div
          style={{
            fontSize: "13px",
            fontWeight: 600,
            marginBottom: "8px",
            color: theme.colors.text.primary,
          }}
        >
          {label}
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "12px" }}>
          {previews.map((src, idx) => (
            <div
              key={idx}
              style={{ position: "relative", width: "100px", height: "100px" }}
            >
              <img
                src={src}
                alt="preview"
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  borderRadius: theme.radius.md,
                  border: `1px solid ${theme.colors.border.DEFAULT}`,
                }}
              />
              <button
                type="button"
                onClick={() => handleRemove(idx)}
                style={{
                  position: "absolute",
                  top: "-8px",
                  right: "-8px",
                  width: "24px",
                  height: "24px",
                  borderRadius: "50%",
                  background: theme.colors.status.error,
                  color: "white",
                  border: "none",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <AiOutlineClose size={12} />
              </button>
            </div>
          ))}
          {(!multiple || previews.length < maxFiles) && !disabled && (
            <div
              onClick={() => fileInputRef.current?.click()}
              style={{
                width: "100px",
                height: "100px",
                border: `2px dashed ${theme.colors.border.DEFAULT}`,
                borderRadius: theme.radius.md,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                background: theme.colors.background.surface,
              }}
            >
              <AiOutlineCamera
                size={24}
                color={theme.colors.text.placeholder}
              />
              <span
                style={{
                  fontSize: theme.typography.fontSize.sm,
                  color: theme.colors.text.placeholder,
                }}
              >
                Subir
              </span>
            </div>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept={acceptedFileTypes}
          multiple={multiple}
          onChange={handleChange}
          style={{ display: "none" }}
          disabled={disabled}
        />
        {error && (
          <div
            style={{
              color: theme.colors.status.error,
              fontSize: theme.typography.fontSize.sm,
              marginTop: "8px",
            }}
          >
            {error}
          </div>
        )}
      </div>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// FORMIK MULTI SELECT (nativo, sin react-select)
// ------------------------------------------------------------------
interface FormikMultiSelectProps {
  name: string;
  label: string;
  options: Option[];
  loading?: boolean;
  disabled?: boolean;
  required?: boolean;
  placeholder?: string;
  responsive?: ResponsiveProps;
  onRefresh?: () => void | Promise<void>;
  onAdd?: () => void;
  onChange?: (value: any, formik: FormikCtx) => void;
}



export function FormikMultiSelect(props: FormikMultiSelectProps) {
  const {
    name,
    label,
    options,
    loading = false,
    disabled = false,
    required = false,
    placeholder = "Seleccione...",
    responsive,
    onRefresh,
    onAdd,
    onChange: externalOnChange,
  } = props;

  const formik = useFormikContext();
  const value: (string | number)[] = formik.values[name] || [];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [dropdownPosition, setDropdownPosition] = useState({
    top: 0,
    left: 0,
    width: 0,
    maxHeight: 200,
    placement: "bottom" as "bottom" | "top",
  });

  const hasValue = value.length > 0;
  const isActive = hasValue || isFocused || isOpen;

  const filteredOptions = options.filter((opt) =>
    opt.label.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const updateDropdownPosition = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    const spaceBelow = windowHeight - rect.bottom;
    const spaceAbove = rect.top;

    const estimatedHeight = Math.min(320, filteredOptions.length * 42 + 90);
    const GAP = 4;

    let topPosition: number;
    let placement: "bottom" | "top";
    let maxHeight: number;

    if (spaceBelow >= estimatedHeight + GAP) {
      placement = "bottom";
      topPosition = rect.bottom + window.scrollY + GAP;
      maxHeight = Math.min(estimatedHeight, spaceBelow - 20);
    } else if (spaceAbove >= estimatedHeight + GAP) {
      placement = "top";
      topPosition = rect.top + window.scrollY - estimatedHeight - GAP;
      maxHeight = Math.min(estimatedHeight, spaceAbove - 20);
    } else {
      placement = "bottom";
      topPosition = rect.bottom + window.scrollY + GAP;
      maxHeight = Math.max(150, spaceBelow - 20);
    }

    setDropdownPosition({
      top: topPosition,
      left: rect.left + window.scrollX,
      width: rect.width,
      maxHeight: Math.max(150, maxHeight),
      placement,
    });
  };

  const openDropdown = () => {
    if (disabled) return;
    updateDropdownPosition();
    setIsOpen(true);
    setIsFocused(true);
    setSearchTerm("");
  };

  const closeDropdown = () => {
    setIsOpen(false);
    setIsFocused(false);
    setSearchTerm("");
  };

  const toggleOpen = () => {
    if (isOpen) closeDropdown();
    else openDropdown();
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        if (
          dropdownRef.current &&
          dropdownRef.current.contains(e.target as Node)
        ) {
          return;
        }
        closeDropdown();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const handleUpdate = () => updateDropdownPosition();
    window.addEventListener("scroll", handleUpdate, true);
    window.addEventListener("resize", handleUpdate);
    return () => {
      window.removeEventListener("scroll", handleUpdate, true);
      window.removeEventListener("resize", handleUpdate);
    };
  }, [isOpen, filteredOptions.length]);

  const toggleValue = (optValue: string | number) => {
    const newValue = value.includes(optValue)
      ? value.filter((v) => v !== optValue)
      : [...value, optValue];
    formik.setFieldValue(name, newValue);
    formik.setFieldTouched(name, true);
    externalOnChange?.(newValue, formik);
  };

  const handleRefresh = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!onRefresh || isRefreshing) return;
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAdd?.();
  };

  const removeChip = (optValue: string | number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newValue = value.filter((v) => v !== optValue);
    formik.setFieldValue(name, newValue);
    formik.setFieldTouched(name, true);
    externalOnChange?.(newValue, formik);
  };

  const actionButtonStyle: React.CSSProperties = {
    padding: "0 7px",
    background: "none",
    border: "none",
    cursor: "pointer",
    color: theme.colors.text.disabled,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "6px",
    height: "28px",
    width: "28px",
    transition: "color 0.15s, background 0.15s",
  };

  if (disabled) {
    const selectedLabels = options
      .filter((opt) => value.includes(opt.value))
      .map((opt) => opt.label);
    return (
      <DisabledField
        label={label}
        value={selectedLabels.join(", ")}
        error={error}
        responsive={responsive}
      />
    );
  }

  return (
    <ColComponent responsive={responsive}>
      <div
        ref={containerRef}
        style={{ position: "relative", marginBottom: "20px" }}
      >
        <label
          style={{
            position: "absolute",
            left: "12px",
            top: isActive ? "-9px" : "14px",
            fontSize: isActive ? "11px" : theme.typography.fontSize.base,
            fontWeight: isActive ? 600 : 400,
            color: isActive
              ? error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary
              : theme.colors.text.placeholder,
            background: theme.colors.background.card,
            padding: "0 4px",
            transition: theme.transitions.DEFAULT,
            zIndex: 2,
            pointerEvents: "none",
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error }}>*</span>
          )}
        </label>

        <div
          onClick={toggleOpen}
          style={{
            display: "flex",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "6px",
            minHeight: "56px",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.border.focus
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            boxShadow: isFocused ? theme.colors.feedback.primaryGlow : "none",
            transition: theme.transitions.DEFAULT,
            padding: "16px 12px 8px",
            cursor: "pointer",
          }}
        >
          {value.map((v) => {
            const opt = options.find((o) => o.value === v);
            if (!opt) return null;
            return (
              <div
                key={v}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: theme.colors.feedback.primaryLight,
                  borderRadius: "6px",
                  padding: "2px 6px",
                  fontSize: theme.typography.fontSize.sm,
                  color: theme.colors.primary.DEFAULT,
                }}
              >
                <span>{opt.label}</span>
                <button
                  type="button"
                  onClick={(e) => removeChip(v, e)}
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    fontSize: "14px",
                    color: theme.colors.primary.DEFAULT,
                    padding: 0,
                  }}
                >
                  ×
                </button>
              </div>
            );
          })}
          {value.length === 0 && (
            <span
              style={{
                color: theme.colors.text.placeholder,
                fontSize: theme.typography.fontSize.base,
              }}
            >
              {placeholder}
            </span>
          )}
          <div style={{ flex: 1 }} />
        </div>

        <div
          style={{
            position: "absolute",
            right: 8,
            top: "50%",
            transform: "translateY(-50%)",
            display: "flex",
            gap: 4,
          }}
        >
          {(onRefresh || onAdd) && (
            <div
              style={{
                width: "1px",
                height: "20px",
                background: theme.colors.border.DEFAULT,
              }}
            />
          )}
          {onRefresh && (
            <button
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              style={actionButtonStyle}
            >
              {isRefreshing ? (
                <div
                  style={{
                    width: 13,
                    height: 13,
                    border: `2px solid ${theme.colors.border.DEFAULT}`,
                    borderTopColor: theme.colors.primary.DEFAULT,
                    borderRadius: "50%",
                    animation: "spin 0.7s linear infinite",
                  }}
                />
              ) : (
                <svg
                  width={14}
                  height={14}
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                >
                  <path d="M1 4v6h6M23 20v-6h-6M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15" />
                </svg>
              )}
            </button>
          )}
          {onAdd && (
            <button type="button" onClick={handleAdd} style={actionButtonStyle}>
              <svg
                width={15}
                height={15}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          )}
          {loading && (
            <div
              style={{
                width: 16,
                height: 16,
                border: `2px solid ${theme.colors.border.DEFAULT}`,
                borderTopColor: theme.colors.primary.DEFAULT,
                borderRadius: "50%",
                animation: "spin 0.7s linear infinite",
                margin: "0 8px",
              }}
            />
          )}
        </div>

        <FieldError error={error} />
      </div>

      {isOpen &&
        createPortal(
          <div
            ref={dropdownRef}
            style={{
              position: "absolute",
              top: dropdownPosition.top,
              left: dropdownPosition.left,
              width: dropdownPosition.width,
              background: theme.colors.background.card,
              border: `1.5px solid ${theme.colors.border.DEFAULT}`,
              borderRadius: theme.radius.md,
              boxShadow: theme.shadows.dropdown,
              zIndex: theme.zIndex.portal,
              maxHeight: dropdownPosition.maxHeight,
              overflow: "auto",
            }}
          >
            <div
              style={{
                padding: "8px",
                borderBottom: `1px solid ${theme.colors.border.DEFAULT}`,
              }}
            >
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar..."
                style={{
                  width: "100%",
                  padding: "8px",
                  border: `1px solid ${theme.colors.border.DEFAULT}`,
                  borderRadius: theme.radius.md,
                  outline: "none",
                  fontSize: "13px",
                }}
              />
            </div>
            <div style={{ padding: "4px" }}>
              {filteredOptions.length === 0 ? (
                <div
                  style={{
                    padding: "12px",
                    textAlign: "center",
                    color: theme.colors.text.disabled,
                  }}
                >
                  Sin opciones
                </div>
              ) : (
                filteredOptions.map((opt) => (
                  <div
                    key={opt.value}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleValue(opt.value);
                    }}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      padding: "8px 12px",
                      cursor: "pointer",
                      borderRadius: theme.radius.md,
                      transition: "background 0.1s",
                    }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.background =
                        theme.colors.feedback.primaryLight)
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.background = "transparent")
                    }
                  >
                    <input
                      type="checkbox"
                      style={{ accentColor: theme.colors.primary[100] }}
                      checked={value.includes(opt.value)}
                      onChange={() => {}}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <span style={{ fontSize: "13.5px" }}>{opt.label}</span>
                  </div>
                ))
              )}
            </div>
            <div
              style={{
                padding: "8px",
                borderTop: `1px solid ${theme.colors.border.DEFAULT}`,
                textAlign: "right",
              }}
            >
              <button
                onClick={closeDropdown}
                style={{
                  padding: "4px 12px",
                  background: theme.colors.primary.DEFAULT,
                  color: "white",
                  border: "none",
                  borderRadius: theme.radius.md,
                  cursor: "pointer",
                }}
              >
                Cerrar
              </button>
            </div>
          </div>,
          document.body,
        )}
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </ColComponent>
  );
}

// ------------------------------------------------------------------
// NOTA: FormikReactSelect (con react-select) se puede eliminar
// ya que no se usa en el código original; si se necesita,
// se puede adaptar de forma similar usando theme.
// ------------------------------------------------------------------

interface FormikDatePickerProps {
  name: string;
  label: string;
  /** @default "date" */
  type?: "date" | "datetime-local" | "time" | "month" | "week";
  min?: string;
  max?: string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  onChange?: (value: string, formik: FormikCtx) => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}







export function FormikDatePicker(props: FormikDatePickerProps) {
  const {
    name,
    label,
    type = "date",
    min,
    max,
    disabled = false,
    readOnly = false,
    required = false,
    onChange,
    onBlur,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isFocused, setIsFocused] = useState(false);
  const datePickerRef = useRef<DatePicker>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const rawValue = formik.values?.[name] ?? "";
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  const selectedDate = rawValue ? new Date(rawValue) : null;

  const handleChange = (date: Date | null) => {
    const value = date ? date.toISOString().split("T")[0] : "";
    formik.setFieldValue(name, value);
    onChange?.(value, formik);
  };

  const handleBlur = () => {
    setIsFocused(false);
    formik.setFieldTouched(name, true);
    onBlur?.({} as React.FocusEvent<HTMLInputElement>);
  };

  // ✅ Abre el calendario y enfoca el input al hacer clic en cualquier parte del contenedor
  const handleContainerClick = () => {
    if (disabled) return;
    // Abre el calendario
    if (datePickerRef.current) {
      datePickerRef.current.setOpen(true);
    }
    // Enfoca el input
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const showTimeSelectOnly = type === "time";
  const showMonthYearPicker = type === "month";
  const showWeekPicker = type === "week";

  const customStyles = `
    .react-datepicker-wrapper {
      width: 100%;
    }
    .react-datepicker {
      font-family: inherit;
      border-radius: ${theme.radius.md};
      border: 1px solid ${theme.colors.border.DEFAULT};
      box-shadow: ${theme.shadows.dropdown};
      background: ${theme.colors.background.card};
    }
    .react-datepicker__header {
      background: ${theme.colors.feedback.primaryLight};
      border-bottom: 1px solid ${theme.colors.border.DEFAULT};
    }
    .react-datepicker__current-month,
    .react-datepicker-time__header,
    .react-datepicker-year-header {
      color: ${theme.colors.text.primary};
      font-weight: 600;
    }
    .react-datepicker__day-name,
    .react-datepicker__day,
    .react-datepicker__time-name {
      color: ${theme.colors.text.primary};
    }
    .react-datepicker__day:hover,
    .react-datepicker__month-text:hover,
    .react-datepicker__quarter-text:hover,
    .react-datepicker__year-text:hover {
      background: ${theme.colors.feedback.primaryLight};
    }
    .react-datepicker__day--selected,
    .react-datepicker__day--in-selecting-range,
    .react-datepicker__day--in-range,
    .react-datepicker__month-text--selected,
    .react-datepicker__month-text--in-selecting-range,
    .react-datepicker__month-text--in-range,
    .react-datepicker__quarter-text--selected,
    .react-datepicker__quarter-text--in-selecting-range,
    .react-datepicker__quarter-text--in-range,
    .react-datepicker__year-text--selected,
    .react-datepicker__year-text--in-selecting-range,
    .react-datepicker__year-text--in-range {
      background: ${theme.colors.primary.DEFAULT};
      color: white;
    }
    .react-datepicker__day--keyboard-selected,
    .react-datepicker__month-text--keyboard-selected,
    .react-datepicker__quarter-text--keyboard-selected,
    .react-datepicker__year-text--keyboard-selected {
      background: ${theme.colors.primary[200]};
      color: white;
    }
    .react-datepicker__day--disabled,
    .react-datepicker__month-text--disabled,
    .react-datepicker__quarter-text--disabled,
    .react-datepicker__year-text--disabled {
      color: ${theme.colors.text.disabled};
    }
    .react-datepicker__close-icon::after {
      background: ${theme.colors.primary.DEFAULT};
    }
    .react-datepicker__day--outside-month {
      color: ${theme.colors.text.disabled};
    }
  `;

  if (disabled) {
    return (
      <ColComponent responsive={responsive} autoPadding={padding}>
        <div style={{ position: "relative", marginBottom: "24px" }}>
          <label
            style={{
              position: "absolute",
              left: "14px",
              top: "-10px",
              fontSize: "11px",
              fontWeight: 600,
              color: theme.colors.text.disabled,
              background: theme.colors.background.surface,
              padding: "0 6px",
              letterSpacing: "0.5px",
              textTransform: "uppercase",
              zIndex: 2,
              borderRadius: "4px",
            }}
          >
            {label}
          </label>
          <div
            style={{
              border: `1px solid ${theme.colors.border.DEFAULT}`,
              borderRadius: theme.radius.lg,
              background: theme.colors.background.surface,
              padding: "14px 16px",
              minHeight: "52px",
              opacity: 0.7,
            }}
          >
            <span
              style={{
                fontSize: theme.typography.fontSize.base,
                color: theme.colors.text.secondary,
              }}
            >
              {rawValue || "—"}
            </span>
          </div>
          <FieldError error={error} />
        </div>
      </ColComponent>
    );
  }

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <style>{customStyles}</style>
      <div style={{ position: "relative", marginBottom: "24px" }}>
        <label
          htmlFor={name}
          style={{
            position: "absolute",
            left: "14px",
            top: "-10px",
            fontSize: "11px",
            fontWeight: 600,
            color: error
              ? theme.colors.status.error
              : isFocused
                ? theme.colors.primary.DEFAULT
                : theme.colors.text.secondary,
            background: theme.colors.background.card,
            padding: "0 6px",
            pointerEvents: "none",
            letterSpacing: "0.5px",
            textTransform: "uppercase",
            transition: "all 0.2s ease",
            zIndex: 2,
            borderRadius: "4px",
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 3 }}>
              *
            </span>
          )}
        </label>

        <div
          onClick={handleContainerClick}
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.lg,
            background: theme.colors.background.card,
            boxShadow: isFocused
              ? error
                ? `0 0 0 3px ${theme.colors.status.error}20`
                : `0 0 0 3px ${theme.colors.primary.DEFAULT}20`
              : "0 1px 2px rgba(0,0,0,0.02)",
            transition: "all 0.2s ease",
            cursor: "pointer",
          }}
        >
          <DatePicker
            ref={datePickerRef}
            selected={selectedDate}
            onChange={handleChange}
            onFocus={() => setIsFocused(true)}
            onBlur={handleBlur}
            disabled={disabled}
            readOnly={readOnly}
            placeholderText="Seleccione una fecha"
            locale={es}
            showTimeSelect={type === "time" || type === "datetime-local"}
            showTimeSelectOnly={type === "time"}
            timeFormat="HH:mm"
            dateFormat={
              type === "time"
                ? "HH:mm"
                : type === "month"
                  ? "MM/yyyy"
                  : type === "week"
                    ? "dd/MM/yyyy"
                    : "dd/MM/yyyy"
            }
            showMonthYearPicker={type === "month"}
            showWeekPicker={type === "week"}
            minDate={min ? new Date(min) : undefined}
            maxDate={max ? new Date(max) : undefined}
            customInput={
              <input
                ref={inputRef}
                style={{
                  flex: 1,
                  padding: "16px 12px 12px 16px",
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  fontSize: theme.typography.fontSize.base,
                  color: theme.colors.text.primary,
                  fontFamily: "inherit",
                  cursor: "pointer",
                }}
              />
            }
          />
          <span
            style={{
              marginRight: 16,
              color: isFocused
                ? theme.colors.primary.DEFAULT
                : theme.colors.text.placeholder,
              pointerEvents: "none",
              display: "flex",
              alignItems: "center",
              transition: "color 0.2s ease",
            }}
          >
            <svg
              width={18}
              height={18}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.8}
              strokeLinecap="round"
            >
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
              <line x1="16" y1="2" x2="16" y2="6" />
              <line x1="8" y1="2" x2="8" y2="6" />
              <line x1="3" y1="10" x2="21" y2="10" />
            </svg>
          </span>
        </div>

        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ──────────────────────────────────────────────────────────────
// 2. FORMIK DATE RANGE
//    Dos DatePickers (desde / hasta) en una sola caja visual
// ──────────────────────────────────────────────────────────────
interface FormikDateRangeProps {
  nameFrom: string;
  nameTo: string;
  labelFrom?: string;
  labelTo?: string;
  min?: string;
  max?: string;
  disabled?: boolean;
  required?: boolean;
  label?: string; // etiqueta general del grupo
  onChange?: (from: string, to: string, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}




export function FormikDateRange(props: FormikDateRangeProps) {
  const {
    nameFrom,
    nameTo,
    labelFrom = "Desde",
    labelTo = "Hasta",
    min,
    max,
    disabled = false,
    required = false,
    label,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [focusedField, setFocusedField] = useState<"from" | "to" | null>(null);

  // Refs para controlar los DatePickers y los inputs internos
  const fromDatePickerRef = useRef<DatePicker>(null);
  const toDatePickerRef = useRef<DatePicker>(null);
  const fromInputRef = useRef<HTMLInputElement>(null);
  const toInputRef = useRef<HTMLInputElement>(null);

  const fromValue = formik.values?.[nameFrom] ?? "";
  const toValue = formik.values?.[nameTo] ?? "";

  const fromDate = fromValue ? new Date(fromValue) : null;
  const toDate = toValue ? new Date(toValue) : null;

  const errorFrom =
    formik.touched[nameFrom] && formik.errors[nameFrom]
      ? String(formik.errors[nameFrom])
      : null;
  const errorTo =
    formik.touched[nameTo] && formik.errors[nameTo]
      ? String(formik.errors[nameTo])
      : null;

  const error = errorFrom || errorTo;
  const isFocused = focusedField !== null;

  const handleFromChange = (date: Date | null) => {
    const value = date ? date.toISOString().split("T")[0] : "";
    formik.setFieldValue(nameFrom, value);
    onChange?.(value, toValue, formik);
  };

  const handleToChange = (date: Date | null) => {
    const value = date ? date.toISOString().split("T")[0] : "";
    formik.setFieldValue(nameTo, value);
    onChange?.(fromValue, value, formik);
  };

  // Abrir calendario y enfocar input del campo "desde"
  const handleFromContainerClick = () => {
    if (disabled) return;
    fromDatePickerRef.current?.setOpen(true);
    fromInputRef.current?.focus();
  };

  // Abrir calendario y enfocar input del campo "hasta"
  const handleToContainerClick = () => {
    if (disabled) return;
    toDatePickerRef.current?.setOpen(true);
    toInputRef.current?.focus();
  };

  const customStyles = `
    .react-datepicker-wrapper {
      width: 100%;
    }
    .react-datepicker {
      font-family: inherit;
      border-radius: ${theme.radius.md};
      border: 1px solid ${theme.colors.border.DEFAULT};
      box-shadow: ${theme.shadows.dropdown};
      background: ${theme.colors.background.card};
    }
    .react-datepicker__header {
      background: ${theme.colors.feedback.primaryLight};
      border-bottom: 1px solid ${theme.colors.border.DEFAULT};
    }
    .react-datepicker__current-month,
    .react-datepicker-time__header,
    .react-datepicker-year-header {
      color: ${theme.colors.text.primary};
      font-weight: 600;
    }
    .react-datepicker__day-name,
    .react-datepicker__day,
    .react-datepicker__time-name {
      color: ${theme.colors.text.primary};
    }
    .react-datepicker__day:hover {
      background: ${theme.colors.feedback.primaryLight};
    }
    .react-datepicker__day--selected,
    .react-datepicker__day--in-range {
      background: ${theme.colors.primary.DEFAULT};
      color: white;
    }
    .react-datepicker__day--keyboard-selected {
      background: ${theme.colors.primary[200]};
      color: white;
    }
    .react-datepicker__day--disabled {
      color: ${theme.colors.text.disabled};
    }
  `;

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <style>{customStyles}</style>
      <div style={{ position: "relative", marginBottom: "24px" }}>
        {label && (
          <label
            style={{
              position: "absolute",
              left: "14px",
              top: "-10px",
              fontSize: "11px",
              fontWeight: 600,
              color: error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary,
              background: theme.colors.background.card,
              padding: "0 6px",
              letterSpacing: "0.5px",
              textTransform: "uppercase",
              zIndex: 2,
              borderRadius: "4px",
            }}
          >
            {label}
            {required && (
              <span style={{ color: theme.colors.status.error, marginLeft: 3 }}>
                *
              </span>
            )}
          </label>
        )}

        <div
          style={{
            display: "flex",
            alignItems: "stretch",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.lg,
            background: theme.colors.background.card,
            boxShadow: isFocused
              ? error
                ? `0 0 0 3px ${theme.colors.status.error}20`
                : `0 0 0 3px ${theme.colors.primary.DEFAULT}20`
              : "0 1px 2px rgba(0,0,0,0.02)",
            transition: "all 0.2s ease",
            overflow: "hidden",
          }}
        >
          {/* FROM - contenedor clickeable */}
          <div
            onClick={handleFromContainerClick}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              padding: "12px 14px 10px",
              transition: "background 0.2s",
              background:
                focusedField === "from"
                  ? `${theme.colors.primary.DEFAULT}08`
                  : "transparent",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color:
                  focusedField === "from"
                    ? theme.colors.primary.DEFAULT
                    : theme.colors.text.disabled,
                textTransform: "uppercase",
                letterSpacing: "0.8px",
                marginBottom: "4px",
              }}
            >
              {labelFrom}
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <DatePicker
                ref={fromDatePickerRef}
                selected={fromDate}
                onChange={handleFromChange}
                onFocus={() => setFocusedField("from")}
                onBlur={() => {
                  setFocusedField(null);
                  formik.setFieldTouched(nameFrom, true);
                }}
                disabled={disabled}
                placeholderText="Seleccione fecha"
                locale={es}
                dateFormat="dd/MM/yyyy"
                minDate={min ? new Date(min) : undefined}
                maxDate={toDate || (max ? new Date(max) : undefined)}
                customInput={
                  <input
                    ref={fromInputRef}
                    style={{
                      flex: 1,
                      border: "none",
                      outline: "none",
                      background: "transparent",
                      fontSize: theme.typography.fontSize.base,
                      color: theme.colors.text.primary,
                      fontFamily: "inherit",
                      padding: "4px 0",
                      cursor: "pointer",
                    }}
                  />
                }
              />
            </div>
          </div>

          {/* Divisor - no clickeable */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              padding: "0 8px",
              color: theme.colors.border.DEFAULT,
              pointerEvents: "none",
            }}
          >
            <svg
              width={18}
              height={18}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.8}
            >
              <line x1="5" y1="12" x2="19" y2="12" />
              <polyline points="12 5 19 12 12 19" />
            </svg>
          </div>

          {/* TO - contenedor clickeable */}
          <div
            onClick={handleToContainerClick}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              padding: "12px 14px 10px",
              transition: "background 0.2s",
              background:
                focusedField === "to"
                  ? `${theme.colors.primary.DEFAULT}08`
                  : "transparent",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color:
                  focusedField === "to"
                    ? theme.colors.primary.DEFAULT
                    : theme.colors.text.disabled,
                textTransform: "uppercase",
                letterSpacing: "0.8px",
                marginBottom: "4px",
              }}
            >
              {labelTo}
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <DatePicker
                ref={toDatePickerRef}
                selected={toDate}
                onChange={handleToChange}
                onFocus={() => setFocusedField("to")}
                onBlur={() => {
                  setFocusedField(null);
                  formik.setFieldTouched(nameTo, true);
                }}
                disabled={disabled}
                placeholderText="Seleccione fecha"
                locale={es}
                dateFormat="dd/MM/yyyy"
                minDate={fromDate || (min ? new Date(min) : undefined)}
                maxDate={max ? new Date(max) : undefined}
                customInput={
                  <input
                    ref={toInputRef}
                    style={{
                      flex: 1,
                      border: "none",
                      outline: "none",
                      background: "transparent",
                      fontSize: theme.typography.fontSize.base,
                      color: theme.colors.text.primary,
                      fontFamily: "inherit",
                      padding: "4px 0",
                      cursor: "pointer",
                    }}
                  />
                }
              />
            </div>
          </div>
        </div>

        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ──────────────────────────────────────────────────────────────
// 3. FORMIK NUMBER DIRECT
//    Input numérico padre: tipado directo + botones ± opcionales
//    prefix/suffix, decimales, rangos, autoformat
// ──────────────────────────────────────────────────────────────
interface FormikNumberDirectProps {
  name: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
  /** Cantidad de decimales a mostrar (undefined = entero) */
  decimals?: number;
  /** Prefijo visual, e.g. "$" */
  prefix?: string;
  /** Sufijo visual, e.g. "kg", "%" */
  suffix?: string;
  /** Muestra los botones +/- al costado del input */
  showStepper?: boolean;
  disabled?: boolean;
  required?: boolean;
  placeholder?: string;
  onChange?: (value: number | null, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikNumberDirect(props: FormikNumberDirectProps) {
  const {
    name,
    label,
    min,
    max,
    step = 1,
    decimals,
    prefix,
    suffix,
    showStepper = false,
    disabled = false,
    required = false,
    placeholder = "",
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const storedValue = formik.values?.[name];
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  const clampValue = useCallback(
    (n: number): number => {
      let v = n;
      if (min !== undefined) v = Math.max(min, v);
      if (max !== undefined) v = Math.min(max, v);
      return v;
    },
    [min, max],
  );

  const handleValueChange = (values: { floatValue: number | undefined }) => {
    let newValue = values.floatValue ?? null;
    if (newValue !== null && !isNaN(newValue)) {
      newValue = clampValue(newValue);
    }
    formik.setFieldValue(name, newValue);
    onChange?.(newValue, formik);
    formik.setFieldTouched(name, true);
  };

  const stepValue = (direction: 1 | -1) => {
    const current =
      storedValue === null || storedValue === undefined
        ? 0
        : Number(storedValue);
    const next = clampValue(current + direction * step);
    formik.setFieldValue(name, next);
    onChange?.(next, formik);
    formik.setFieldTouched(name, true);
  };

  const hasValue =
    storedValue !== null && storedValue !== undefined && storedValue !== "";
  const isActive = hasValue || isFocused;

  if (disabled) {
    const displayValue =
      storedValue !== null && storedValue !== undefined && storedValue !== ""
        ? decimals !== undefined
          ? Number(storedValue).toFixed(decimals)
          : String(storedValue)
        : "—";
    return (
      <ColComponent responsive={responsive} autoPadding={padding}>
        <div style={{ position: "relative", marginBottom: "20px" }}>
          <label
            style={{
              position: "absolute",
              left: "12px",
              top: "-9px",
              fontSize: "11px",
              fontWeight: 600,
              color: theme.colors.text.disabled,
              background: theme.colors.background.surface,
              padding: "0 4px",
              letterSpacing: "0.04em",
              textTransform: "uppercase",
              zIndex: 2,
            }}
          >
            {label}
          </label>
          <div
            style={{
              border: `1.5px solid ${theme.colors.border.DEFAULT}`,
              borderRadius: theme.radius.md,
              background: theme.colors.background.surface,
              padding: "13px 12px",
              minHeight: "50px",
              display: "flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            {prefix && (
              <span
                style={{
                  color: theme.colors.text.disabled,
                  fontSize: theme.typography.fontSize.sm,
                }}
              >
                {prefix}
              </span>
            )}
            <span
              style={{
                fontSize: theme.typography.fontSize.base,
                color: theme.colors.text.secondary,
              }}
            >
              {displayValue}
            </span>
            {suffix && (
              <span
                style={{
                  color: theme.colors.text.disabled,
                  fontSize: theme.typography.fontSize.sm,
                }}
              >
                {suffix}
              </span>
            )}
          </div>
          <FieldError error={error} />
        </div>
      </ColComponent>
    );
  }

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ position: "relative", marginBottom: "20px" }}>
        {/* Floating label */}
        <label
          htmlFor={name}
          style={{
            position: "absolute",
            left: prefix ? "32px" : "12px",
            top: isActive ? "-9px" : "14px",
            fontSize: isActive ? "11px" : theme.typography.fontSize.base,
            fontWeight: isActive ? 600 : 400,
            color: isActive
              ? error
                ? theme.colors.status.error
                : isFocused
                  ? theme.colors.primary.DEFAULT
                  : theme.colors.text.secondary
              : theme.colors.text.placeholder,
            background: isActive ? theme.colors.background.card : "transparent",
            padding: "0 4px",
            pointerEvents: "none",
            transition: theme.transitions.DEFAULT,
            letterSpacing: isActive ? "0.04em" : "0",
            textTransform: isActive ? "uppercase" : "none",
            zIndex: 2,
          }}
        >
          {label}
          {required && (
            <span style={{ color: theme.colors.status.error, marginLeft: 2 }}>
              *
            </span>
          )}
        </label>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            border: `1.5px solid ${
              error
                ? theme.colors.border.error
                : isFocused
                  ? theme.colors.border.focus
                  : theme.colors.border.DEFAULT
            }`,
            borderRadius: theme.radius.md,
            background: theme.colors.background.card,
            boxShadow: isFocused
              ? error
                ? "0 0 0 3px rgba(220,38,38,0.10)"
                : theme.colors.feedback.primaryGlow
              : "none",
            transition: theme.transitions.DEFAULT,
            overflow: "hidden",
          }}
        >
          {/* Stepper - */}
          {showStepper && (
            <button
              type="button"
              onClick={() => stepValue(-1)}
              style={{
                width: 36,
                height: "100%",
                minHeight: 48,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: theme.colors.background.surface,
                border: "none",
                borderRight: `1px solid ${theme.colors.border.DEFAULT}`,
                cursor: "pointer",
                color: theme.colors.text.secondary,
                flexShrink: 0,
                transition: "background 0.1s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background =
                  theme.colors.feedback.primaryLight)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background =
                  theme.colors.background.surface)
              }
            >
              <svg
                width={12}
                height={12}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2.5}
                strokeLinecap="round"
              >
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          )}

          {/* Input numérico con formato - sin customInput */}
          <NumericFormat
            getInputRef={inputRef}
            id={name}
            value={storedValue ?? ""}
            onValueChange={handleValueChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => {
              setIsFocused(false);
              formik.setFieldTouched(name, true);
            }}
            disabled={disabled}
            placeholder={isFocused ? placeholder : ""}
            prefix={prefix}
            suffix={suffix}
            decimalScale={decimals}
            fixedDecimalScale={decimals !== undefined}
            allowNegative={min === undefined || min < 0}
            decimalSeparator="."
            thousandSeparator=","
            step={step}
            min={min}
            max={max}
            style={{
              flex: 1,
              padding: `20px 8px 8px ${prefix ? "4px" : showStepper ? "8px" : "12px"}`,
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: theme.typography.fontSize.base,
              color: theme.colors.text.primary,
              fontFamily: "inherit",
              textAlign: showStepper ? "center" : "left",
              fontWeight: showStepper ? 600 : 400,
              minWidth: 0,
            }}
          />

          {/* Stepper + */}
          {showStepper && (
            <button
              type="button"
              onClick={() => stepValue(1)}
              style={{
                width: 36,
                height: "100%",
                minHeight: 48,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: theme.colors.background.surface,
                border: "none",
                borderLeft: `1px solid ${theme.colors.border.DEFAULT}`,
                cursor: "pointer",
                color: theme.colors.text.secondary,
                flexShrink: 0,
                transition: "background 0.1s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background =
                  theme.colors.feedback.primaryLight)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background =
                  theme.colors.background.surface)
              }
            >
              <svg
                width={12}
                height={12}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2.5}
                strokeLinecap="round"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          )}

          {/* Indicador min/max */}
          {isFocused && (min !== undefined || max !== undefined) && (
            <div
              style={{
                padding: "0 10px",
                display: "flex",
                flexDirection: "column",
                gap: 1,
                alignItems: "flex-end",
                flexShrink: 0,
              }}
            >
              {max !== undefined && (
                <span
                  style={{
                    fontSize: "9px",
                    color: theme.colors.text.disabled,
                    lineHeight: 1,
                  }}
                >
                  máx {max}
                </span>
              )}
              {min !== undefined && (
                <span
                  style={{
                    fontSize: "9px",
                    color: theme.colors.text.disabled,
                    lineHeight: 1,
                  }}
                >
                  mín {min}
                </span>
              )}
            </div>
          )}
        </div>

        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}

// ──────────────────────────────────────────────────────────────
// 4. FORMIK SLIDER
//    Slider con track visual, marks opcionales y valor en tooltip
// ──────────────────────────────────────────────────────────────
interface FormikSliderMark {
  value: number;
  label: string;
}

interface FormikSliderProps {
  name: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
  /** Unidad que aparece junto al valor, e.g. "%" o "km" */
  unit?: string;
  /** Muestra el valor actual flotando sobre el thumb */
  showTooltip?: boolean;
  /** Marcas en la pista */
  marks?: FormikSliderMark[];
  disabled?: boolean;
  required?: boolean;
  onChange?: (value: number, formik: FormikCtx) => void;
  responsive?: ResponsiveProps;
  padding?: boolean;
}

export function FormikSlider(props: FormikSliderProps) {
  const {
    name,
    label,
    min = 0,
    max = 100,
    step = 1,
    unit = "",
    showTooltip = true,
    marks,
    disabled = false,
    required = false,
    onChange,
    responsive = { sm: 12, md: 12, lg: 12, xl: 12, "2xl": 12 },
    padding = true,
  } = props;

  const formik = useFormikContext<Record<string, any>>();
  const [isDragging, setIsDragging] = useState(false);
  const trackRef = useRef<HTMLDivElement>(null);

  const rawValue = formik.values?.[name];
  const value =
    rawValue !== undefined && rawValue !== null ? Number(rawValue) : min;
  const error =
    formik.touched[name] && formik.errors[name]
      ? String(formik.errors[name])
      : null;

  const percentage = max === min ? 0 : ((value - min) / (max - min)) * 100;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVal = Number(e.target.value);
    formik.setFieldValue(name, newVal);
    onChange?.(newVal, formik);
  };

  const primaryColor = theme.colors.primary.DEFAULT;
  const primaryLight = theme.colors.feedback.primaryLight;

  return (
    <ColComponent responsive={responsive} autoPadding={padding}>
      <div style={{ marginBottom: "28px" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "baseline",
            marginBottom: "14px",
          }}
        >
          <label
            htmlFor={name}
            style={{
              fontSize: "12px",
              fontWeight: 600,
              color: error
                ? theme.colors.status.error
                : isDragging
                  ? primaryColor
                  : theme.colors.text.secondary,
              letterSpacing: "0.5px",
              textTransform: "uppercase",
              transition: "color 0.2s",
            }}
          >
            {label}
            {required && (
              <span style={{ color: theme.colors.status.error, marginLeft: 3 }}>
                *
              </span>
            )}
          </label>

          <div
            style={{
              display: "flex",
              alignItems: "baseline",
              gap: "3px",
              padding: "4px 12px",
              borderRadius: "40px",
              background: isDragging ? primaryColor : primaryLight,
              transition: "all 0.2s",
              boxShadow: isDragging ? "0 2px 8px rgba(0,0,0,0.1)" : "none",
            }}
          >
            <span
              style={{
                fontSize: "15px",
                fontWeight: 700,
                color: isDragging ? "#ffffff" : primaryColor,
                transition: "color 0.2s",
                fontVariantNumeric: "tabular-nums",
              }}
            >
              {value}
            </span>
            {unit && (
              <span
                style={{
                  fontSize: "11px",
                  fontWeight: 500,
                  color: isDragging ? "rgba(255,255,255,0.85)" : primaryColor,
                }}
              >
                {unit}
              </span>
            )}
          </div>
        </div>

        <div style={{ position: "relative", padding: "8px 0" }}>
          <div
            ref={trackRef}
            style={{
              position: "relative",
              height: "6px",
              borderRadius: "6px",
              background: theme.colors.border.DEFAULT,
              margin: "10px 0",
            }}
          >
            <div
              style={{
                position: "absolute",
                left: 0,
                top: 0,
                height: "100%",
                width: `${percentage}%`,
                borderRadius: "6px",
                background: error
                  ? theme.colors.status.error
                  : disabled
                    ? theme.colors.text.disabled
                    : primaryColor,
                transition: isDragging
                  ? "none"
                  : "width 0.15s cubic-bezier(0.4, 0, 0.2, 1)",
              }}
            />

            {marks?.map((mark) => {
              const markPct =
                max === min ? 0 : ((mark.value - min) / (max - min)) * 100;
              return (
                <div
                  key={mark.value}
                  style={{
                    position: "absolute",
                    left: `${markPct}%`,
                    top: "50%",
                    transform: "translate(-50%, -50%)",
                    width: "4px",
                    height: "4px",
                    borderRadius: "50%",
                    background:
                      mark.value <= value
                        ? "#ffffff"
                        : theme.colors.text.disabled,
                    boxShadow: "0 0 0 1px rgba(0,0,0,0.05)",
                    pointerEvents: "none",
                  }}
                />
              );
            })}
          </div>

          <input
            id={name}
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            disabled={disabled}
            onChange={handleChange}
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => {
              setIsDragging(false);
              formik.setFieldTouched(name, true);
            }}
            onTouchStart={() => setIsDragging(true)}
            onTouchEnd={() => {
              setIsDragging(false);
              formik.setFieldTouched(name, true);
            }}
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              opacity: 0,
              cursor: disabled ? "not-allowed" : "pointer",
              margin: 0,
              padding: 0,
              zIndex: 2,
            }}
          />

          <div
            style={{
              position: "absolute",
              top: "50%",
              left: `${percentage}%`,
              transform: "translate(-50%, -50%)",
              width: isDragging ? "22px" : "18px",
              height: isDragging ? "22px" : "18px",
              borderRadius: "50%",
              background: error
                ? theme.colors.status.error
                : disabled
                  ? theme.colors.text.disabled
                  : "#ffffff",
              border: `2px solid ${error ? theme.colors.status.error : primaryColor}`,
              boxShadow: isDragging
                ? `0 0 0 6px ${primaryLight}, 0 4px 12px rgba(0,0,0,0.15)`
                : "0 2px 6px rgba(0,0,0,0.1)",
              transition: isDragging
                ? "width 0.1s, height 0.1s, box-shadow 0.2s"
                : "all 0.2s cubic-bezier(0.2, 0.9, 0.4, 1.1)",
              pointerEvents: "none",
              zIndex: 3,
            }}
          />
        </div>

        {marks && marks.length > 0 && (
          <div
            style={{ position: "relative", height: "24px", marginTop: "6px" }}
          >
            {marks.map((mark) => {
              const markPct =
                max === min ? 0 : ((mark.value - min) / (max - min)) * 100;
              return (
                <span
                  key={mark.value}
                  style={{
                    position: "absolute",
                    left: `${markPct}%`,
                    transform: "translateX(-50%)",
                    fontSize: "10px",
                    color:
                      mark.value <= value
                        ? primaryColor
                        : theme.colors.text.disabled,
                    fontWeight: mark.value === value ? 600 : 400,
                    whiteSpace: "nowrap",
                    transition: "color 0.2s",
                  }}
                >
                  {mark.label}
                </span>
              );
            })}
          </div>
        )}

        {!marks && (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginTop: "6px",
            }}
          >
            <span
              style={{ fontSize: "10px", color: theme.colors.text.disabled }}
            >
              {min}
              {unit}
            </span>
            <span
              style={{ fontSize: "10px", color: theme.colors.text.disabled }}
            >
              {max}
              {unit}
            </span>
          </div>
        )}

        <FieldError error={error} />
      </div>
    </ColComponent>
  );
}